import { useEffect, useRef } from "react";
import * as pdfjsLib from "pdfjs-dist";
import pdfWorker from "pdfjs-dist/build/pdf.worker?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export default function PdfReader({ pdf }) {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!pdf) return;

    const renderPdf = async () => {
      containerRef.current.innerHTML = "";

      const pdfUrl = URL.createObjectURL(pdf);
      const loadingTask = pdfjsLib.getDocument(pdfUrl);
      const pdfDoc = await loadingTask.promise;

      for (let pageNum = 1; pageNum <= pdfDoc.numPages; pageNum++) {
        const page = await pdfDoc.getPage(pageNum);

        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");

        canvas.width = viewport.width;
        canvas.height = viewport.height;

        await page.render({
          canvasContext: context,
          viewport,
        }).promise;

        canvas.style.width = "100%";
        canvas.style.marginBottom = "1rem";

        containerRef.current.appendChild(canvas);
      }

      URL.revokeObjectURL(pdfUrl);
    };

    renderPdf();
  }, [pdf]);

  return (
    <div>
      <h3>📄 Aperçu du PDF</h3>
      <div ref={containerRef} />
    </div>
  );
}
