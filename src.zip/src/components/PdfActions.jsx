export default function PdfActions({ pdf }) {

  const handleSaveOrShare = async () => {
    const fileName = `photos-${Date.now()}.pdf`;
    const file = new File([pdf], fileName, {
      type: "application/pdf",
    });

    /* ===== TENTATIVE PARTAGE NATIF ===== */
    if (navigator.share) {
      try {
        await navigator.share({
          files: [file],
          title: "Photos → PDF",
          text: "Voici le PDF généré depuis l’application Photos → PDF",
        });
        return; // ✅ succès → on s’arrête là
      } catch (err) {
        // ❌ partage refusé / non supporté → on continue
        console.log("Partage impossible, fallback téléchargement");
      }
    }

    /* ===== FALLBACK GARANTI : TÉLÉCHARGEMENT ===== */
    const url = URL.createObjectURL(pdf);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;

    // requis sur mobile
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  };

  return (
    <div className="pdf-actions">
      <button className="primary" onClick={handleSaveOrShare}>
        💾 Enregistrer / Partager le PDF
      </button>
    </div>
  );
}
